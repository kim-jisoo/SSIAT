
export const ButtonItems = [
    {
        title: '요리배우기',
        url: '#',
        cName: 'carousel-links',
        id: '1'
    },
    {
        title: '기타배우기',
        url: '#',
        cName: 'carousel-links',
        id: '2'
    },
    {
        title: '하이킹 클럽',
        url: '#',
        cName: 'carousel-links',
        id: '3'
    },
    {
        title: '오후의 티타임',
        url: '#',
        cName: 'carousel-links',
        id: '4'
    },
    {
        title: '함께 예배하기',
        url: '#',
        cName: 'carousel-links',
        id: '5'
    },
    {
        title: '필라테스',
        url: '#',
        cName: 'carousel-links',
        id: '6'
    },
    {
        title: '정물화 그리기',
        url: '#',
        cName: 'carousel-links',
        id: '7'
    },
    {
        title: '시니어 댄스 ',
        url: '#',
        cName: 'carousel-links',
        id: '8'
    },
    {
        title: 'filler',
        url: '#',
        cName: 'carousel-links',
        id: '9'
    },
    
    
]